window.csfunc = {
    appendHtml: function (id, html) {
        document.getElementById(id).innerHTML = html;
    }
};